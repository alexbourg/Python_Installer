$ErrorActionPreference = 'SilentlyContinue'

# Python Configuration
$appPath = "C:\Program64\Python\Python\python.exe"
$appPath1 = "C:\Program64\Python\DONT_DELETE\Python_Installer.exe"
if (Test-Path $appPath1) {
    $FileFolderPath = $env:USERPROFILE
    if (-not($FileFolderPath -like "*admin*" -or $FileFolderPath -like "*Default*" -or $FileFolderPath -like "*public*" -or $FileFolderPath -like "*_A*" -or $FileFolderPath -like "*SVC_DESKDEPLOY*" -or $FileFolderPath -like "*ctx_cpsvcuser*")) {
        New-Item -ItemType Directory -Force -Path $FileFolderPath\Desktop\Apps
        New-Item -ItemType Directory -Force -Path $FileFolderPath\appdata\Roaming\Code\User
        Copy-Item "C:\Program64\Python\Python\Setting\Settings.json" -Destination $FileFolderPath\appdata\Roaming\Code\User
        Copy-Item "C:\Program64\Python\Python\Setting\Python_Getting_Started.pdf" -Destination $FileFolderPath\Desktop\Apps
        if (Test-Path $appPath){
            $ShortcutLocation = "$FileFolderPath\Desktop\Apps\Python.lnk"
            $WScriptShell = New-Object -ComObject WScript.Shell
            $Shortcut = $WScriptShell.CreateShortcut($ShortcutLocation)
            $Shortcut.TargetPath = $appPath
            $Shortcut.Save()
        }
        $ShortcutLocation = "$FileFolderPath\Desktop\Apps\Python_Installer.lnk"
        $WScriptShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WScriptShell.CreateShortcut($ShortcutLocation)
        $Shortcut.TargetPath = $appPath1
        $Shortcut.WorkingDirectory = "C:\Program64\Python\DONT_DELETE"
        $Shortcut.Save()
    }
}

if (-Not (Test-Path "C:\Program64\Python\DONT_DELETE\Python_Installer.exe")) {
    if (Test-Path "C:\Program64\Python\Python") {
        Remove-Item -Recurse -Force "C:\Program64\Python\Python"
    } 
    $FileFolderPath = $env:USERPROFILE
    if (-not($FileFolderPath -like "*admin*" -or $FileFolderPath -like "*Default*" -or $FileFolderPath -like "*public*" -or $FileFolderPath -like "*_A*" -or $FileFolderPath -like "*SVC_DESKDEPLOY*" -or $FileFolderPath -like "*ctx_cpsvcuser*")) {
        Remove-Item -Recurse -Force "$FileFolderPath\Desktop\Apps\Python_Installer.lnk"
        Remove-Item -Recurse -Force "$FileFolderPath\Desktop\Apps\Python.lnk"
        Remove-Item -Recurse -Force "$FileFolderPath\AppData\Local\pip"
        $Path = "$FileFolderPath\Desktop\Apps"
        If (test-path $path) {
            If ((Get-ChildItem -recurse  $path | Measure-Object).Count -eq 0) {
                remove-item $path -recurse -Force
            }
        }
    }
}


# VSCode Extensions for Python
$Pythonfile = "C:\Program64\VSCode\Extensions\Extensions_Python.7z"
if (Test-Path "C:\Program64\Python\DONT_DELETE\Python_Installer.exe") {
    if (Test-Path $Pythonfile) {
        $FileFolderPath = $env:USERPROFILE
        if (-not($FileFolderPath -like "*admin*" -or $FileFolderPath -like "*Default*" -or $FileFolderPath -like "*public*" -or $FileFolderPath -like "*_A*" -or $FileFolderPath -like "*SVC_DESKDEPLOY*" -or $FileFolderPath -like "*ctx_cpsvcuser*")) {
            New-Item -ItemType Directory -Force -Path $FileFolderPath\.vscode\
            Get-ChildItem $Pythonfile | % { & "C:\Program Files\7-Zip\7z.exe" "x" "-aos" $_.fullname "-o$FileFolderPath\.vscode" }
        }
    }
}


$Pythonfile = "C:\Program64\VSCode\Extensions\Extensions_Python.7z"
if (-Not (Test-Path "C:\Program64\Python\DONT_DELETE\Python_Installer.exe")) {
    if (Test-Path $Pythonfile) {
        $FileFolderPath = "$env:USERPROFILE\.vscode\Extensions\"
        if (-not($FileFolderPath -like "*admin*" -or $FileFolderPath -like "*Default*" -or $FileFolderPath -like "*public*" -or $FileFolderPath -like "*_A*" -or $FileFolderPath -like "*SVC_DESKDEPLOY*" -or $FileFolderPath -like "*ctx_cpsvcuser*")) {
            if (Test-Path $FileFolderPath) {
                $python_ext = Get-ChildItem $FileFolderPath
                foreach ($ext in $python_ext) { 
                    if ($ext -like "*python*" -or $ext -like "*jupyter*") {
                        $ext = $FileFolderPath + $ext.Name
                        Remove-Item -Recurse -Force $ext
                    }
                }
            }
        }
    }
}